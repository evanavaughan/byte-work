## Day 3 Exercise 0.

* Ask the user to input integers or 'done', if they print an integer print that integer converted to a float
with 2 0's after the decimal point (remember format?)

* If they type done exit the program

* Know how to do this two different ways

* * Using while True and a break statement

* * Setting an input variable outside the loop and using a test with while.

* Now finish any exercises from yesterday that needed while that you still need to do.