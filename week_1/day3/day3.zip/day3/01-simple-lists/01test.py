fruit = "banana"
print(fruit[-1])
