
def multiply(x=1, y=2, z=3):
    return x * y * z