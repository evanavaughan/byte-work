## Day 5 Exercise 3 - Word Count
---

##### Objective 1 

* Write a function that takes a filename, examines the file, and prints the most common word.

##### Objective 2

* Write a function that takes a filename, examines the file, and prints the n most common words in
descending order.

##### Hint:

* Create your own simple file with test data

* This would be a good time for a data structure that has words for keys instead of numbers.