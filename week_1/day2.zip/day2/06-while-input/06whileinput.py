#* Write a program that asks a user to input an integer, and keeps asking the user to input integers until they input 'done'
int(input("Please give me a number: "))
print("If you want to give another number, please input another number. Otherwise write 'done'.")
