for y in range(0,100,10):
    for x in range(0, 10):
        print(x+y, end = "")
    print("\n")
