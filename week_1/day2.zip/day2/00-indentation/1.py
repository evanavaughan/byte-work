if 1 > 2:
    print("Hello ", end="")
else:
    print("World!")