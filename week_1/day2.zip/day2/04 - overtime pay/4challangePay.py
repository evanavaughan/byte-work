hours = float(input("How many hours did you work?: "))
rate = float(input("What is your rate per hour?: "))

if hours <= 40:
    print(hours*rate)
else:
    print(40*rate+(hours-40)*1.5*rate)
