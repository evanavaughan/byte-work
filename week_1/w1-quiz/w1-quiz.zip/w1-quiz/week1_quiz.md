## Week 1 Quiz

#### Assignment:

* Write a function called ```square_list(a_list)``` that takes a list of integers as its argument

* It should print "<> squared is <>." on a line for each element in the list.

* So ```square_list([2,3,4,5])``` would output

```
2 squared is 4.
3 squared is 9.
4 squared is 16.
5 squared is 25.
```

#### Partial credit:

* If you can't get the function to work for a list, have it output the line for just a single number as its input.