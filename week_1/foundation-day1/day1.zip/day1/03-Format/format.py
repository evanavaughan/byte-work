a = "3"
b = "little pigs"

print("The {} {}".format(a,b))


d = 6.7
print("{:.2f}".format(d))

e = "Sam"
f = "Josephine"
print("The joint account for {:<12} and {:<12} has $1000.".format(e,f))