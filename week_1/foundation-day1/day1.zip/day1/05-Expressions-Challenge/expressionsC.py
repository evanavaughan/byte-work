x = float(input("How many hours did you work?"))
y = float(input("How much do you make per hour?"))
print("Great! Looks like you made" , x*y)