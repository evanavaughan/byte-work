## Foundation Week 2 Exercise 1

#### Put your work on github!

* Put your work for this course up on github!

* You may want to create a different repository for each week, or just one for the whole course. You may even wish to create one for each day, but that might be a lot to keep track of.

* Push your work to your repository! You should now be able to submit work by sending me a link to a folder in a repo.

* Git can be frustrating at first. You'll get (heh) the hang of it.