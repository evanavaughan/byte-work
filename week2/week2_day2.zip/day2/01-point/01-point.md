## Foundation Day 2 Exercise 1

* Write a class called Point

* It has two attributes, x and y

* p = Point should create an object with x and y equal to 0

* create a method called display() that prints "Point: (<x>, <y>)"
* where x and y are the attributes
