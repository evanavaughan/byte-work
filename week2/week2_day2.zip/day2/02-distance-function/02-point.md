## Foundation Week 2 Day 2 Exercise 2

# Distance function

# take your Point class from the previous exercise and add a new method:
#

# Point.distance(p) where p is another point that returns a floating point
# value for the distance between the two points
# if one point is (x1, y1) and another point is (x2, y2) then the formula
# for distance is 
# math.sqrt((x1 - x2) `**` 2 + (y1 - y2) `**` 2)
